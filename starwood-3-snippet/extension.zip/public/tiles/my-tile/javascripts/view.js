jive.tile.onOpen(function(config, options) {

    $("#config_string").text(config["configString"]);

    gadgets.window.adjustHeight();
});